package com.mrjuniormkt.max

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

data class ChatLine(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val executor = Executors.newSingleThreadExecutor()
    private var onSpeechResult: ((String) -> Unit)? = null

    // Add your own HTTPS backend URL here. Never put an AI provider secret key in this app.
    private val backendUrl = "https://YOUR_BACKEND_URL/chat"

    private val micPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startListeningInternal()
        else onSpeechResult?.invoke("माइक्रोफोन अनुमति नहीं मिली। आप टाइप करके बात कर सकते हैं।")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        }
        setContent {
            MaxApp(
                onListen = { callback ->
                    onSpeechResult = callback
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        startListeningInternal()
                    } else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                },
                onSend = { message, reply -> handleMessage(message, reply) }
            )
        }
    }

    private fun startListeningInternal() {
        val recognizer = speechRecognizer ?: run {
            onSpeechResult?.invoke("इस मोबाइल पर Speech Recognition उपलब्ध नहीं है।")
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "MAX को अपना आदेश बोलें")
        }
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { onSpeechResult?.invoke("आवाज़ समझ नहीं आई। दोबारा कोशिश करें।") }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                onSpeechResult?.invoke(text ?: "मैं समझ नहीं पाया।")
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        recognizer.startListening(intent)
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "MAX_REPLY")
    }

    private fun handleMessage(message: String, reply: (String) -> Unit) {
        val m = message.lowercase(Locale.ROOT)
        when {
            m.contains("सेटिंग") || m.contains("settings") -> {
                startActivity(Intent(Settings.ACTION_SETTINGS))
                reply("मोबाइल की Settings खोल रहा हूँ।")
            }
            m.contains("यूट्यूब") || m.contains("youtube") -> {
                startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.youtube.com")))
                reply("YouTube खोल रहा हूँ।")
            }
            m.contains("समय") || m.contains("time") -> {
                val now = java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date())
                reply("अभी समय $now है।")
            }
            m.contains("नमस्ते") || m.contains("hello") || m.contains("हेलो") -> {
                reply("नमस्ते! मैं MAX हूँ। बताइए, आपकी क्या मदद करूँ?")
            }
            else -> askBackend(message, reply)
        }
    }

    private fun askBackend(message: String, reply: (String) -> Unit) {
        if (backendUrl.contains("YOUR_BACKEND_URL")) {
            reply("मैं MAX हूँ। बेसिक कमांड चालू हैं। Online AI चालू करने के लिए सुरक्षित Backend URL जोड़ना होगा।")
            return
        }
        executor.execute {
            var answer = "अभी Online AI से संपर्क नहीं हो पाया।"
            try {
                val connection = (URL(backendUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 12000
                    readTimeout = 20000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                }
                connection.outputStream.use {
                    it.write(JSONObject().put("message", message).toString().toByteArray(Charsets.UTF_8))
                }
                val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
                val body = stream.bufferedReader().use { it.readText() }
                val json = JSONObject(body)
                answer = json.optString("reply", answer)
                connection.disconnect()
            } catch (_: Exception) {}
            runOnUiThread { reply(answer) }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("hi", "IN")
        }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.shutdown()
        executor.shutdown()
        super.onDestroy()
    }
}

@Composable
fun MaxApp(onListen: ((String) -> Unit) -> Unit, onSend: (String, (String) -> Unit) -> Unit) {
    var input by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf(ChatLine("नमस्ते! मैं MAX हूँ। बोलिए या लिखिए।", false)) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF66D9FF),
        background = Color(0xFF080D1B),
        surface = Color(0xFF111A2D)
    )) {
        Column(
            modifier = Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF101D3A), Color(0xFF080D1B))))
                .padding(18.dp)
        ) {
            Text("MAX", color = Color.White, fontSize = 34.sp)
            Text("YOUR PERSONAL AI ASSISTANT", color = Color(0xFF66D9FF), fontSize = 11.sp)
            Spacer(Modifier.height(18.dp))
            Surface(shape = RoundedCornerShape(22.dp), color = Color(0xFF172541), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.size(104.dp).background(
                            Brush.linearGradient(listOf(Color(0xFF1D8BCE), Color(0xFF7547D8))),
                            CircleShape
                        ),
                        contentAlignment = Alignment.Center
                    ) { Text("M", color = Color.White, fontSize = 48.sp) }
                    Spacer(Modifier.height(8.dp))
                    Text(if (listening) "सुन रहा हूँ..." else "आपका AI साथी", color = Color.White)
                    Text("Hybrid AI • Voice • Android", color = Color.LightGray, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
            LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(messages) { item ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (item.fromUser) Arrangement.End else Arrangement.Start) {
                        Surface(
                            color = if (item.fromUser) Color(0xFF164C70) else Color(0xFF202B42),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.widthIn(max = 300.dp)
                        ) { Text(item.text, color = Color.White, modifier = Modifier.padding(12.dp)) }
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    modifier = Modifier.weight(1f), placeholder = { Text("MAX से बात करें...") },
                    singleLine = true
                )
                IconButton(onClick = {
                    listening = true
                    onListen { spoken ->
                        listening = false
                        input = spoken
                    }
                }) { Icon(Icons.Default.Mic, contentDescription = "बोलें", tint = Color(0xFF66D9FF)) }
                IconButton(onClick = {
                    val msg = input.trim()
                    if (msg.isNotEmpty()) {
                        messages.add(ChatLine(msg, true))
                        input = ""
                        onSend(msg) { answer ->
                            messages.add(ChatLine(answer, false))
                        }
                    }
                }) { Icon(Icons.Default.Send, contentDescription = "भेजें", tint = Color(0xFF66D9FF)) }
            }
            Text("कुछ मोबाइल कार्रवाइयों के लिए अनुमति आवश्यक होगी।", color = Color.Gray, fontSize = 10.sp)
        }
    }
}
