# MAX Android Assistant (Starter v1)

## Included
- Android app project using Kotlin + Jetpack Compose
- Hindi speech input using Android SpeechRecognizer
- Hindi text-to-speech replies
- Local commands: open Android Settings, open YouTube, tell current time
- Hybrid AI connection hook using an HTTPS backend endpoint
- Safe placeholder: no provider API key is embedded in the app

## Build
1. Open this folder in Android Studio (Giraffe or newer; recent version recommended).
2. Let Gradle sync.
3. Connect your Android phone with USB debugging enabled, or use an emulator.
4. Press Run.

To create an APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

## Enable Online AI
In `MainActivity.kt`, replace:
`https://YOUR_BACKEND_URL/chat`
with your own HTTPS backend endpoint.

The backend should accept POST JSON:
`{"message":"user prompt"}`

and return JSON:
`{"reply":"assistant response"}`

Keep the AI provider secret key on the backend only. Do not put it in this Android project.

## Important limitations
- This is a starter build, not a signed production APK.
- Always-on wake word, background listening, WhatsApp automation, call automation, and broad device control are not included in v1. They require additional Android services, permissions, user consent, and device-specific testing.
- Speech recognition may use Android/Google speech services and may require internet depending on the device.
